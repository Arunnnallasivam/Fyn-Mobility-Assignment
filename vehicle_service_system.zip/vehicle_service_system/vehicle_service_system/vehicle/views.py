from django.shortcuts import render, redirect
from .models import Repair
from django.http import JsonResponse
from .models import Vehicle, Component
from django.http import HttpResponse

def home(request):
    components = Component.objects.all()
    vehicles = Vehicle.objects.all()
    repairs = Repair.objects.all()
    return render(request, 'home.html', {'components': components, 'vehicles': vehicles, 'repairs': repairs})

def register_component(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        price = request.POST.get('price')
        is_new = request.POST.get('is_new') == 'on'
        Component.objects.create(name=name, price=price, is_new=is_new)
        return redirect('home')
    return render(request, 'register_component.html')

def calculate_final_price(request):
    vehicle_id = request.GET.get('vehicle_id')
    repairs = Repair.objects.filter(vehicle_id=vehicle_id)
    total_price = sum([repair.repair_cost for repair in repairs])
    return JsonResponse({'total_price': total_price})

def home(request):
    return HttpResponse("Welcome to the Vehicle Service System!")
