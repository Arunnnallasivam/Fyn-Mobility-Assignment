from django.urls import path
from . import views
from vehicle.views import FrontendAppView


urlpatterns = [
    path('', views.home, name='home'),
    path('register-component/', views.register_component, name='register_component'),
    path('calculate-price/', views.calculate_final_price, name='calculate_price'),
    path('', frontend.as_view(), name='index'),
]
