import React from 'react';
import Home from './Home';
import RevenueChart from './RevenueChart';

function App() {
    const data = [
        { month: 'Jan', revenue: 500 },
        { month: 'Feb', revenue: 700 },
        { month: 'Mar', revenue: 800 },
    ];

    return (
        <div>
            <Home />
            <RevenueChart data={data} />
        </div>
    );
}

export default App;
