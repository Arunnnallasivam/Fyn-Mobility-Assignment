import React, { useState, useEffect } from 'react';

function Home() {
    const [components, setComponents] = useState([]);
    const [vehicles, setVehicles] = useState([]);
    const [setRepairs] = useState([]);
    const [totalPrice, setTotalPrice] = useState(0);

    useEffect(() => {
        // Fetch components and vehicles from the backend
        setComponents([{ name: 'Engine', price: 200 }, { name: 'Brake Pads', price: 50 }]);
        setVehicles([{ vin: '1HGBH41JXMN109186', make: 'Toyota', model: 'Camry', year: 2020 }]);
        setRepairs([{ vehicle: 'Toyota Camry', component: 'Engine', cost: 200 }]);
    }, []);

    const calculatePrice = async () => {
        const vehicle_id = 1;  // Example vehicle id
        const response = await fetch(`/calculate-price?vehicle_id=${vehicle_id}`);
        const data = await response.json();
        setTotalPrice(data.total_price);
    };

    return (
        <div>
            <h1>Vehicle Service Management</h1>
            <h2>Components</h2>
            <ul>
                {components.map(comp => (
                    <li key={comp.name}>{comp.name} - ${comp.price}</li>
                ))}
            </ul>

            <h2>Vehicles</h2>
            <ul>
                {vehicles.map(vehicle => (
                    <li key={vehicle.vin}>{vehicle.make} {vehicle.model} ({vehicle.year})</li>
                ))}
            </ul>

            <button onClick={calculatePrice}>Calculate Final Price</button>

            <h3>Total Price: ${totalPrice}</h3>
        </div>
    );
}

export default Home;
